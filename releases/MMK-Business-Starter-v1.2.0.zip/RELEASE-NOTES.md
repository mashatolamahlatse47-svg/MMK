# MMK Business Starter v1.2.0

## New in v1.2.0

### Reports & Activity History

The Reports section has been upgraded with a persistent Activity History.

The application records meaningful business actions with:

- Date and time
- Action
- Category
- Details

Activity History records important events such as:

- Products added, updated, or removed
- Customers added or removed
- Sales recorded
- Customer debt activity
- Business information changes
- Stock-related activity

Activity History is stored on the device and remains available after a browser refresh.

## Existing Reports

The following reports remain available:

- Business Summary
- Sales History
- Customer Debt Report
- Product & Stock Report

## Testing

The Reports and Activity History workflow was tested locally in the browser and passed.

The test confirmed that:

- Activity is recorded.
- Activity details are displayed.
- Reports render correctly.
- Activity History persists after refresh.

## Release

**Version:** 1.2.0
